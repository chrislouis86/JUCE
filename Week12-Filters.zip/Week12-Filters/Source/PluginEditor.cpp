/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
Week12filtersAudioProcessorEditor::Week12filtersAudioProcessorEditor (Week12filtersAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 300);
    slider1.setRange (20.0f, 10000.0f);
    slider1.setValue (400.0f);
    slider1.setPopupDisplayEnabled (true, false, this);
    slider1.setSliderStyle(juce::Slider::LinearBarVertical);
    slider1.setSkewFactor(0.2);
    addAndMakeVisible (&slider1);
    slider1.addListener (this);
}

Week12filtersAudioProcessorEditor::~Week12filtersAudioProcessorEditor()
{
}

//==============================================================================
void Week12filtersAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));
    g.setColour (juce::Colours::white);
    g.setFont(16.0f);
    g.drawText("Low Pass Filter Slider", getLocalBounds(), juce::Justification::centredTop, true);
}

void Week12filtersAudioProcessorEditor::resized()
{
    slider1.setBounds (40, 30, 25, getHeight()-60); // X, Y, Width, Height
}

void Week12filtersAudioProcessorEditor::sliderValueChanged(juce::Slider *slider)
{
    processor.slider1Value = slider1.getValue();
}
